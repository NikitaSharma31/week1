﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practice_1
{
    class Student
    {
        private string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private string[] names = new string[10];

        public string this[int i] {
            get { return names[i]; }
            set { names[i] = value; }
        }

        
    }
}

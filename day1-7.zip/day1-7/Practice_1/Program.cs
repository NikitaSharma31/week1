﻿using System;
using System.CodeDom;

namespace Practice_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Write the text you want to convert into speech");

            Student stdName = new Student();

           stdName.Name = "nikita";
            Console.WriteLine(stdName.Name);


            stdName[0] = "mera";
            stdName[1] = "naam";
            stdName[2] = "nikita";
            stdName[3] = "hai";
            for(int i=0; i < 10; i++)
            {
                Console.WriteLine(stdName[i]);
            }

            foreach (int item in stdName[i])
            {
                Console.WriteLine(item);
            }
        }
    }
}

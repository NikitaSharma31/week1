﻿using System;
//using static Exception_handling.TempIsZeroException;
using static Exception_handling.UnderAgeException;

namespace Exception_handling
{
    class Program
    {
        static void Main(string[] args)
        {


            /*  int order;
            Console.Write("Enter your order");
            
            try {
                order = int.Parse(Console.ReadLine());
                if (order > 5) { throw new Exception("outOfStock"); }
                else
                {
                    Console.WriteLine("InStock");
                }

            }

            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }

            ////////////////////////////////////////////////////////////////
           Console.WriteLine("Hello World!");
             Console.WriteLine("Hello World!");

             int[] arr = { 1, 2, 3,4,3};

             try

             {//Displaying it 

                 for (int i = 0; i < arr.Length; i++)

                 {

                     Console.WriteLine(arr[i]);

                 }

                 Console.WriteLine(arr[3]);

             }

             catch (IndexOutOfRangeException e)

             {

                 Console.WriteLine(" An Exception Has occured : {0},{1}", e.Message, e.StackTrace);

                 // throw; 

             }

             catch (DivideByZeroException e)

             {

                 Console.WriteLine("An Exception has occured :{0}", e.Message);

             }

             finally

             { 
                 Console.WriteLine("Finally Blocks runs irrespective of Exception..!!");

                 for (int i = 0; i < arr.Length; i++)

                 {

                     Console.WriteLine("{0}", arr[i]);

                 }



             }

             Console.WriteLine("userdefined exception");

             Temperature temp = new Temperature();
             try
             {
                 temp.showTemp();
             }
             catch(TempIsZeroException e)
             {
                 Console.WriteLine(""+ e.Message);
             }
            ////////////////////////////////////////////////////
            ///*/
            Console.WriteLine("UserDefined exception////////////////////////");
            AgeOfUser age = new AgeOfUser();

            try
            {
              age.Validation(3);
            }
            catch (UnderAgeException e)
            {
                Console.WriteLine(""+ e.Message);
            }
            ////////////////////////////////////////////////////////////////////////
            ///




        }


    }
}


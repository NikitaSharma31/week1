﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception_handling
{
    /*  public class TempIsZeroException : Exception
      {

          public TempIsZeroException(string message) : base(message)
          {

          }
          internal class Temperature
          {
              int temperature = 0;
              public void showTemp()
              {
                  if (temperature == 0)
                  {
                      throw (new TempIsZeroException("Zero temperature found"));
                  }
                  else
                  {
                      Console.WriteLine("temperature: {0}" , temperature);
                  }
              }
          }
      }*/

    public class UnderAgeException : Exception
    {
    
    public UnderAgeException ( string message) : base(message)
        {

        }

        internal class AgeOfUser {
            //int Age = 27;


            public void Validation(int Age )
            {
                if (Age < 20)
                {
                    throw (new UnderAgeException("You are under age"));
                }
                else
                {
                    Console.WriteLine("your age is: {0} " ,Age);
                }
            }
            


          

        }

    }

}

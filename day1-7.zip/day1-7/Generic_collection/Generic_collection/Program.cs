﻿using System;
using System.Globalization;
using System.Linq;
using System.Collections.Generic;

namespace Generic_collection
{
    class Program
    {
        public void empDet(params object[] val)
        {
            Console.WriteLine("Inside Show Function");
            for (int i = 0; i < val.Length; i++)
            {
                Console.WriteLine(val[i]);
            }

        }









        /*  Console.WriteLine("Dictionary");

          Dictionary<string, Int16> myDec = new Dictionary<string, Int16>();

          myDec.Add("Aurthor1", 1);
          myDec.Add("Aurthor2", 2);
          myDec.Add("Aurthor3", 3);

          Console.WriteLine("Aurthor List");
          foreach(var item in myDec.Keys)
          {
              Console.WriteLine(item);
          }
          */

        /*  int[][] myarr = new int[2][];
          myarr[0] = new int[3] { 22, 33, 44};
          myarr[1] = new int[2] { 88, 88 };
          myarr[2] = new int[4] { 99, 77, 55, 55 };
         foreach(var ){

          }
         */



        static void Main(string[] args)
        {
            Program myData = new Program();
            myData.empDet("aman", "21", "aman.gunawat@.com");



        }

    }
}

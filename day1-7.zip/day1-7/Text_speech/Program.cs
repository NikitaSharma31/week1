﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Speech.Synthesis;

namespace Text_speech
{
    class Program
    {
        static void Main(string[] args)
        {
            SpeechSynthesizer obj = new SpeechSynthesizer();
            obj.Speak("mummy pad mt maro");
            obj.Speak("hi aditya how are you i love you");
        }
    }
}

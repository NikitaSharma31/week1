﻿using System;

namespace Delegate_practice
{
	class Program
	{


		public delegate void DelMethod(int x , int y);

		public void add(int x , int y)
		{
			Console.WriteLine("add of numbers :{0}", x + y);
		}


		static void Main(string[] args)
		{
			Console.WriteLine("Single casting delegate");


			program obj = new program();
			DelMethod delobj= new DelMethod(program.add);
			delobj(6 , 7);

		}
	}
}


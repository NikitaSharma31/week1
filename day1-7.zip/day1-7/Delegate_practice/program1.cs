﻿using System;

namespace Delegate_practice
{
    internal class program
    {
        internal void Show(int x, int y)
        {
            throw new NotImplementedException();
        }

        internal static void Add(int x, int y)
        {
            throw new NotImplementedException();
        }

        internal static void add(int x, int y)
        {
            throw new NotImplementedException();
        }
    }
}
﻿using System;

namespace Text_to_Speech
{
    internal class SpeechSynthesizer
    {
        public SpeechSynthesizer()
        {
        }

        internal void Speak(string v)
        {
            throw new NotImplementedException();
        }
    }
}
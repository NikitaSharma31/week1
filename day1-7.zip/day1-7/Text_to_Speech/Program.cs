﻿namespace Text_to_Speech
{
    class Program
    {
        static void Main(string[] args)
        {
           
                var synthesizer = new SpeechSynthesizer();
             ;
                synthesizer.Speak("All we need to do is to make sure we keep talking");
            }
        }
    }
}
    }
}

﻿using System;

namespace Operator_overloading
{
    class Program
    {
        static void Main(string[] args)
        {
            /* Console.WriteLine("operator overloading  ");
             Calculator calc = new Calculator(15, -25);
             calc = -calc;
             calc.Print();*/


            Console.WriteLine( "reference equality!!!!!!!!!!!!!!!!!!!");
            Equal eql1 = new Equal { ID = 1, name = "nikita", addres = "house" };
            Equal eql2 = new Equal { ID = 4, name = "nikita", addres = "house" };
            Equal eql3 = new Equal { };
            Console.WriteLine(eql1==eql2);
            Console.WriteLine(eql1.Equals(eql2));
            eql3 = eql1;
            Console.WriteLine(eql1 == eql2);
            Console.WriteLine(eql1.Equals(eql2));
            // Console.WriteLine(System.Object.ReferenceEquals(eql1,eql2));
            //Console.WriteLine(eql1.CompareTo(eql2));

            Console.WriteLine( eql1.GetHashCode());
            Console.WriteLine(eql2.GetHashCode());

        }
    }
    }


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operator_overloading
{
    class Equal
    {
        public int ID { get; set; }
        public string name { get; set; }
        public string addres { get; set; }

        internal int CompareTo(Equal eql2)
        {
            throw new NotImplementedException();
        }
    }
}

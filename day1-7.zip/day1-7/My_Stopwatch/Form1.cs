﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace My_Stopwatch
{
    public partial class Form1 : Form
    {
        int seconds;
            int minutes;
        int hours;

        public Form1()
        {
            InitializeComponent();
            seconds = minutes = hours = 0;
           
        }
        private void Form_load(object sender, EventArgs e)
        {
            

        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            seconds++;
            if (seconds > 59)
            {
                minutes++;
                seconds = 0;
            }
            if (minutes > 59)
            {
                hours++;
                minutes = 0;
            }
            if (hours > 99)
            {
                seconds = 0;
                minutes = 0;
                hours = 0;
            }

            label4.Text = hours.ToString();
            label5.Text = minutes.ToString();
            label6.Text = seconds.ToString();
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void Stop_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }
    }
}

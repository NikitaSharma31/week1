﻿using System.Globalization;
using System;
using System.Linq;


namespace Demo_maths
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Array");
            int[] arr = { 1, 2, 3, 4, 5 };
            for(int i=0;i<arr.Length;i++)
            {
                Console.WriteLine(arr[i]);
            }
            //..................................
            foreach(var el in arr)
            {
                Console.WriteLine(el);

            }
            //...............
            Console.WriteLine( arr.Min());
            Console.WriteLine(arr.Max());
            arr.Sum();
            Console.WriteLine(arr);




            /* Console.WriteLine("what is the date and time now");
             DateTime nowDatetime = DateTime.Now;
            Console.WriteLine(nowDatetime);
             Console.WriteLine(nowDatetime.ToString("D"));
             Console.WriteLine(nowDatetime.ToString("dddd"));
             Console.WriteLine(nowDatetime.ToString("yy"));
             Console.WriteLine(nowDatetime.ToString("M")); 

           CultureInfo currCulture = new CultureInfo("ja-JP");
           Console.WriteLine(currCulture);
           string dateInJapan = nowDatetime.ToString("ddd",new CultureInfo("ja-JP"));
           Console.WriteLine(dateInJapan);



           /* Console.WriteLine("Enter the number for day of a week :");
            int day =Convert.ToInt32( Console.ReadLine());
            switch (day)
            {
                case 1:
                    Console.WriteLine("Monday");
                     break;

                case 2:
                    Console.WriteLine("tuesday");
                    break;

                case 3:
                    Console.WriteLine("wedneday");
                    break;
                case 4:
                    Console.WriteLine("thursday");
                    break;
                case 5:
                    Console.WriteLine("friday");
                    break;
                case 6:
                    Console.WriteLine("saturday");
                    break;
                case 7:
                    Console.WriteLine("sunday");
                    break;

                default:
                    Console.WriteLine("invalid");
                    break;


            }*/
        }
    }
}
